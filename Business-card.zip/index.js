 favouriteMovieGenre("cowboy")
 favouriteFruit("Banana")